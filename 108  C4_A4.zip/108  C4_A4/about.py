me = {
        "first": "Mario",
        "last": "Camarillo",
        "age": 41,
        "hobbies": [],
        "address": {
            "street": "mia",
            "number": 123,
            "city": "Mesa",
            "state": "Camarillo",
            "zip": 91234
        }
}